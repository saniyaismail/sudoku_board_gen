import tensorflow as tf
from tensorflow.keras import layers
from gym import spaces
import numpy as np
from stable_baselines.common.policies import ActorCriticPolicy, FeedForwardPolicy
from stable_baselines.common.distributions import CategoricalProbabilityDistributionType, ProbabilityDistributionType, CategoricalProbabilityDistribution, ProbabilityDistribution
from stable_baselines.a2c.utils import conv, linear, conv_to_fc

def FullyConv1(image, n_tools, **kwargs):
    activ = tf.nn.relu
    x = activ(conv(image, 'c1', n_filters=32, filter_size=3, stride=1,
        pad='SAME', init_scale=np.sqrt(2)))
    x = activ(conv(x, 'c2', n_filters=64, filter_size=3, stride=1,
        pad='SAME', init_scale=np.sqrt(2)))
    x = activ(conv(x, 'c3', n_filters=64, filter_size=3, stride=1,
        pad='SAME', init_scale=np.sqrt(2)))
    x = activ(conv(x, 'c4', n_filters=64, filter_size=3, stride=1,
        pad='SAME', init_scale=np.sqrt(2)))
    x = activ(conv(x, 'c5', n_filters=64, filter_size=3, stride=1,
        pad='SAME', init_scale=np.sqrt(2)))
    x = activ(conv(x, 'c6', n_filters=64, filter_size=3, stride=1,
        pad='SAME', init_scale=np.sqrt(2)))
    x = activ(conv(x, 'c7', n_filters=64, filter_size=3, stride=1,
        pad='SAME', init_scale=np.sqrt(2)))
    x = activ(conv(x, 'c8', n_filters=n_tools, filter_size=3, stride=1,
        pad='SAME', init_scale=np.sqrt(2)))
    act = conv_to_fc(x)
    val = activ(conv(x, 'v1', n_filters=64, filter_size=3, stride=2,
        init_scale=np.sqrt(2)))
    val = activ(conv(val, 'v4', n_filters=64, filter_size=1, stride=1,
        init_scale=np.sqrt(2)))
    val = conv_to_fc(val)
    return act, val


class MaskedCategoricalProbabilityDistribution(CategoricalProbabilityDistribution):
    def __init__(self, logits, mask):
        self.mask = tf.cast(mask, tf.float32)
        # Add a very small log to mask out forbidden actions by assigning them a large negative value
        masked_logits = logits + tf.math.log(self.mask + 1e-8)
        super().__init__(logits=masked_logits)

class MaskedCategoricalPdType(ProbabilityDistributionType):
    def __init__(self, n_cat):
        self.n_cat = n_cat

    def probability_distribution_class(self):
        return MaskedCategoricalProbabilityDistribution

    def proba_distribution_from_latent(self, pi_latent_vector, vf_latent_vector, mask, init_scale=1.0, init_bias=0.0):
        pdparam = pi_latent_vector
        q_values = vf_latent_vector
        return MaskedCategoricalProbabilityDistribution(pdparam, mask), pdparam, q_values
    def param_shape(self):
        return [self.n_cat]

    def sample_shape(self):
        return []

    def sample_dtype(self):
        return tf.int64
    

class FullyConvPolicySmallMap(ActorCriticPolicy):
    def __init__(self, sess, ob_space, ac_space, n_env, n_steps, n_batch, **kwargs):
        super(FullyConvPolicySmallMap, self).__init__(sess, ob_space, ac_space, n_env, n_steps, n_batch, **kwargs)

        # Observation shape: [batch, H, W, 20] → first 10 channels = map, last 10 = mask
        self.map_obs = self.processed_obs[:, :, :, :10]
        self.mask = tf.reshape(self.processed_obs[:, :, :, 10:], [-1, ac_space.n])  # Flatten mask
        self.mask = tf.cast(self.mask, tf.float32)

        n_tools = int(ac_space.n / (ob_space.shape[0] * ob_space.shape[1]))

        self._pdtype = MaskedCategoricalPdType(ac_space.n)

        with tf.variable_scope("model", reuse=kwargs.get('reuse', None)):
            pi_latent, vf_latent = FullyConv1(self.map_obs, n_tools, **kwargs)
            self._value_fn = linear(vf_latent, 'vf', 1)

            self._proba_distribution, self._policy, self.q_value = \
                self._pdtype.proba_distribution_from_latent(
                    pi_latent,
                    vf_latent,
                    mask=self.mask,
                    init_scale=0.01
                )

        self._setup_init()

    def step(self, obs, state=None, mask=None, deterministic=False):
        # Run session to get outputs
        action_probs, value, neglogp = self.sess.run(
            [self.policy_proba, self.value_flat, self.neglogp],
            {self.obs_ph: obs}
        )

        # Apply the mask from the input (assumes last 10 channels of obs)
        batch_mask = obs[:, :, :, 10:]  # shape: [B, H, W, 10]
        batch_mask = batch_mask.reshape((obs.shape[0], -1))  # shape: [B, A]
        batch_mask = batch_mask.astype(np.float32)

        action_probs = action_probs * batch_mask
        action_probs = action_probs / (np.sum(action_probs, axis=-1, keepdims=True) + 1e-8)

        if deterministic:
            action = np.argmax(action_probs, axis=-1)
        else:
            action = np.array([
                np.random.choice(action_probs.shape[1], p=probs)
                for probs in action_probs
            ])

        return action, value, self.initial_state, neglogp

    def proba_step(self, obs, state=None, mask=None):
        action_probs = self.sess.run(self.policy_proba, {self.obs_ph: obs})

        batch_mask = obs[:, :, :, 10:].reshape((obs.shape[0], -1)).astype(np.float32)
        action_probs = action_probs * batch_mask
        action_probs = action_probs / (np.sum(action_probs, axis=-1, keepdims=True) + 1e-8)

        return action_probs

    def value(self, obs, state=None, mask=None):
        return self.sess.run(self.value_flat, {self.obs_ph: obs})

class CustomPolicySmallMap(FeedForwardPolicy):
    def __init__(self, *args, **kwargs):
        super(CustomPolicySmallMap, self).__init__(*args, **kwargs, cnn_extractor=Cnn1, feature_extraction="cnn")

