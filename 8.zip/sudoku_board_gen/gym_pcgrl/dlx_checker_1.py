import subprocess
import tempfile
import os

class SudokuSolverDLX:
    def __init__(self, exe_dir="dlx/exe"):
        self.exe_dir = exe_dir

    def has_multiple_solutions(self, board):
        """
        Check if the Sudoku board has multiple solutions or a unique solution.
        Returns:
            0 if the board has a unique solution.
            1 if the board has multiple solutions.
        """
        # Convert the board to string format, where empty cells are represented by '.'
        board_str = ''.join(str(cell) if cell != 0 else '.' for row in board for cell in row)

        # # Print the board string format
        # print("Board to be written to file:", board_str)

        # Create a temporary file to store the board string
        with tempfile.NamedTemporaryFile(delete=False) as temp_file:
            temp_filename = temp_file.name
            temp_file.write(board_str.encode('utf-8'))

        # Run the DLX solver via the subprocess call
        try:
            command = f"./sudoku solver < {temp_filename}"
            result = subprocess.run(command, shell=True, cwd=self.exe_dir, capture_output=True, text=True)

            '''with open(temp_filename, 'rb') as input_file:
                result = subprocess.run(
                    ["./sudoku", "solver"],
                    cwd=self.exe_dir,
                    stdin=input_file,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True  # supported in Python 3.7.1
                )'''

            # # Print the stdout (solved board)
            # print("Output (stdout):", result.stdout.strip())

            # # Print the stderr (status message)
            # print("Error/Status (stderr):", result.stderr.strip())

            # Check for "Multiple solution found" in stderr
            if "Multiple solutions" in result.stderr:
                return 2  # Multiple solutions
            elif "Unique solution" in result.stderr:
                return 1  # Unique solution
            elif "No solution found." in result.stderr:
                return 0
        finally:
            # Clean up the temporary file
            os.remove(temp_filename)

if __name__ == "__main__":
    string = "1..92....524.1...........7..5...81.2.........4.27...9..6...........3.945....71..6"
    b1 = []
    cnt = 0
    b2 = []
    for a in string :
        if a == "." : 
            b2.append(0)
        else : 
            b2.append(a)
        cnt = cnt + 1

        if cnt == 9 : 
            b1.append(b2)
            cnt = 0
            b2 = []



#     board = [    [0, 0, 0, 0, 0, 9, 0, 4, 0],
# [2, 6, 0, 7, 0, 0, 0, 0, 0],#
# [7, 2, 1, 0, 0, 9, 0, 8, 0],
# [0, 0, 0, 7, 1, 2, 0, 7, 0],
# [0, 0, 0, 0, 0, 0, 3, 0, 1],
# [4, 8, 0, 0, 0, 9, 0, 7, 0],
# [0, 3, 8, 9, 0, 0, 0, 0, 0],
# [0, 0, 0, 2, 0, 3, 5, 0, 3],
# [0, 1, 0, 0, 0, 0, 0, 0, 0]
#     ]

    board = [    [0, 0, 2, 0, 6, 0, 0, 0, 1],
    [0, 0, 0, 4, 0, 9, 3, 0, 0],
    [0, 0, 0, 0, 0, 1, 0, 8, 7],
    [0, 0, 0, 3, 0, 0, 0, 1, 9],
    [3, 0, 1, 0, 2, 0, 6, 0, 0],
    [0, 6, 0, 0, 1, 7, 0, 0, 0],
    [0, 0, 3, 6, 0, 5, 0, 0, 0],
    [9, 0, 8, 0, 4, 0, 0, 6, 0],
    [0, 0, 0, 1, 8, 0, 4, 0, 0]
    ]

    checker = SudokuSolverDLX()
    print(board)
    result = checker.has_multiple_solutions(board)
    print(result)  # 1 for unique, 2 for multiple

