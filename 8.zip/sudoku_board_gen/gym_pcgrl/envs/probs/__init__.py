from gym_pcgrl.envs.probs.sudoku_prob import SudokuProblem

# all the problems should be defined here with its corresponding class
PROBLEMS = {
    "sudoku" : SudokuProblem
}
