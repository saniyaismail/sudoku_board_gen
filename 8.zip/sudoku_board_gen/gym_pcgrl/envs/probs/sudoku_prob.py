from gym_pcgrl.envs.probs.problem import Problem
from gym_pcgrl.envs.reps.wide_rep import WideRepresentation
from gym_pcgrl.dlx_checker_1 import SudokuSolverDLX
import numpy as np
from gym_pcgrl.envs.helper import pretty_print_sudoku, pretty_print_validity_map
from PIL import Image
import os


class SudokuProblem(Problem):
    def __init__(self):
        super().__init__()
        self._prob_name = "sudoku"
        self._rep = WideRepresentation()
        self._max_steps = 200
        self._width = 9
        self._height = 9
        self._tile_size = 16
        self._min_clues = 17
        self._max_clues = 30  # soft limit
        self._border_size = (0, 0)
        self._start_stats = {"game_map": [[str(0) for _ in range(self._width)] for _ in range(self._height)]
                             ,"num_clues": 0, "solutions": 0}
        # self._prev_map = [[str(0) for _ in range(self._width)] for _ in range(self._height)]
        self.iteration = 0
        # self.reward = 0

    def get_tile_types(self):
        return [str(i) for i in range(10)]  # 0 = empty

    def reset(self, start_stats=None):
        super().reset(start_stats or {"num_clues": 0, "solutions": 0})
        # print("[RESET] Initializing empty board...")
        return self._start_stats

    def get_stats(self, game_map):
        board = [[int(cell) for cell in row] for row in game_map]
        num_clues = sum(1 for row in board for val in row if val != 0)
        solutions = self.estimate_solutions(board)
        return {"game_map": game_map, "num_clues": num_clues, "solutions": solutions}

    def estimate_solutions(self, board):
        checker = SudokuSolverDLX()
        result = checker.has_multiple_solutions(board)
        return result

    def board_is_valid(self, board):
        for r in range(9):
            for c in range(9):
                val = board[r][c]
                if val != 0:
                    board[r][c] = 0
                    if not self.is_valid_move(board, r, c, val):
                        board[r][c] = val
                        return False
                    board[r][c] = val
        return True

    def is_valid_move(self, board, row, col, val):
        for i in range(9):
            if board[row][i] == val or board[i][col] == val:
                return False
        box_r, box_c = 3 * (row // 3), 3 * (col // 3)
        for i in range(box_r, box_r + 3):
            for j in range(box_c, box_c + 3):
                if board[i][j] == val:
                    return False
        return True
    
    def get_action_mask(self, game_map):
        mask = [[[0 for _ in range(10)] for _ in range(9)] for _ in range(9)]
        for r in range(9):
            for c in range(9):
                current_val = game_map[r][c]
                for val in range(10):  # 0-9
                    if val == current_val:
                        mask[r][c][val] = 1
                    elif val != 0 and current_val == 0:
                        if self.is_valid_move(game_map, r, c, val):
                            # Simulate the move
                            game_map[r][c] = val
                            if self.estimate_solutions(game_map) != 0:  # Keep only if board is solvable
                                mask[r][c][val] = 1
                            game_map[r][c] = 0  # Undo move
                    elif val == 0 and current_val != 0:
                        game_map[r][c] = 0
                        if self.estimate_solutions(game_map) != 0:
                            mask[r][c][val] = 1
                        game_map[r][c] = current_val
        return mask



    def get_reward(self, new_stats, old_stats):
    
        reward = 0
    
        prev_map = old_stats["game_map"]  # use from old_stats
        current_map = new_stats["game_map"]  # use from new_stats
        
    
        board = [[int(cell) for cell in row] for row in prev_map]  # to validate against prev state\

        validity_map = []
        for r in range(9):
            row = []
            for c in range(9):
                val = board[r][c]
                if val != 0:
                    board[r][c] = 0  # Temporarily clear
                    row.append(self.is_valid_move(board, r, c, val))
                    board[r][c] = val  # Restore
                else:
                    row.append(False)
            validity_map.append(row)

        
        # print("This is  the validity_map")
        # print(validity_map)
        # pretty_print_validity_map(validity_map)
    
        diff = [(r, c) for r in range(9) for c in range(9)
                if prev_map[r][c] != current_map[r][c]]
    
        r, c = -1, -1
        new_val = -1
        old_val = -1

        if len(diff) > 1:
            print("[ERROR] More than one change detected in a single step!")
            print("Changes:", diff)
            raise ValueError("Multiple changes in a single step!")

    
        if len(diff) == 1:
            r, c = diff[0]
            old_val = int(prev_map[r][c])
            new_val = int(current_map[r][c])

            old_valid = validity_map[r][c]
            if new_val != 0:
                board[r][c] = 0  # Temporarily clear the cell
                new_valid = self.is_valid_move(board, r, c, new_val)
                board[r][c] = new_val  # Restore the value
            else:
                new_valid = False


            if new_val == 0 and old_val != 0:
                # Check if the old value was invalid
                if old_valid:
                    reward -= 2  # Penalize for clearing a valid clue
                else:
                    reward += 0.1 # Giving reward for clearing the invalid clue 

            elif new_val != 0:
                if not new_valid:
                    # print("Not valid move")
                    reward -= 5
                elif old_val == 0:
                    reward += 2  # valid new placement in empty cell
                    # print("Valid new placement in empty cell")
                elif old_val != 0 and new_val != old_val:
                    if old_valid and not new_valid:
                        reward -= 1  # replaced valid with invalid
                        # print("replaced valid with invalid")
                    elif not old_valid and new_valid:
                        reward += 2  # corrected previously invalid cell
                        # print("corrected previously invalid cell")
                    elif old_valid and new_valid:
                        reward -= 0.2  # valid-over-valid overwrite
                        # print("valid-over-valid overwrite")
                    else:
                        reward -= 0.5  # invalid-over-invalid overwrite
                        # print("invalid-over-invalid overwrite")

        elif len(diff) == 0:
            reward -= 0.05  # no-op
            # print("no op")

        if(self.board_is_valid(board)):
            if new_stats["solutions"] == 1 and old_stats["solutions"] != 2:
                reward += 10  # solved uniquely
                # print("unique solution")
            
            if new_stats["solutions"] == 0:
                reward -= 10  # severely penalize unsolvable state
                # print("Unsolvable board")
    
        if new_stats["num_clues"] > self._max_clues:
            reward -= 1  # too many clues
            # print("too many cues")
    
        self.iteration += 1
        
        # print(f"\nStep Debug: {self.iteration}")
        if diff:
        #     print(f"Action: ({r}, {c}) → {new_val} (was {old_val})")
        # print(f"Clues: {new_stats['num_clues']}, Solutions: {new_stats['solutions']}")
        # print(f"Reward: {reward:.2f}")
        # print("This is the prev_map")
        # pretty_print_sudoku(prev_map)

        # print("This is the new Map")
        # pretty_print_sudoku(current_map)
            pass
    
        return reward

    def get_episode_over(self, new_stats, old_stats):
        # print("EPISODE OVER\n")
        # print("episode over or not", (new_stats["solutions"] == 1 and self.board_is_valid(new_stats["game_map"]) and new_stats["num_clues"] >= self._min_clues)
        #     or (new_stats["num_clues"] > self._max_clues))
        return (new_stats["solutions"] == 1 and new_stats["num_clues"] >= self._min_clues) \
            or (new_stats["num_clues"] > self._max_clues)


    def get_debug_info(self, new_stats, old_stats):
        return {
            "clues": new_stats["num_clues"],
            "solutions": new_stats["solutions"],
            "prev_solutions": old_stats["solutions"],
            "map": new_stats["game_map"]
        }
    

    """
    Get an image on how the map will look like for a specific map

    Parameters:
        map (string[][]): the current game map

    Returns:
        Image: a pillow image on how the map will look like using sudoku graphics
    """
    def render(self, map):
        if self._graphics == None:

            self._graphics = {
                '0': Image.open(os.path.join(os.path.dirname(__file__), "sudoku/0_.png")).convert('RGBA').resize((self._tile_size, self._tile_size)),
                '1': Image.open(os.path.join(os.path.dirname(__file__), "sudoku/1_.png")).convert('RGBA').resize((self._tile_size, self._tile_size)),
                '2': Image.open(os.path.join(os.path.dirname(__file__), "sudoku/2_.png")).convert('RGBA').resize((self._tile_size, self._tile_size)),
                '3': Image.open(os.path.join(os.path.dirname(__file__), "sudoku/3_.png")).convert('RGBA').resize((self._tile_size, self._tile_size)),
                '4': Image.open(os.path.join(os.path.dirname(__file__), "sudoku/4_.png")).convert('RGBA').resize((self._tile_size, self._tile_size)),
                '5': Image.open(os.path.join(os.path.dirname(__file__), "sudoku/5_.png")).convert('RGBA').resize((self._tile_size, self._tile_size)),
                '6': Image.open(os.path.join(os.path.dirname(__file__), "sudoku/6_.png")).convert('RGBA').resize((self._tile_size, self._tile_size)),
                '7': Image.open(os.path.join(os.path.dirname(__file__), "sudoku/7_.png")).convert('RGBA').resize((self._tile_size, self._tile_size)),
                '8': Image.open(os.path.join(os.path.dirname(__file__), "sudoku/8_.png")).convert('RGBA').resize((self._tile_size, self._tile_size)),
                '9': Image.open(os.path.join(os.path.dirname(__file__), "sudoku/9_.png")).convert('RGBA').resize((self._tile_size, self._tile_size)),
            }

        return super().render(map)
    

