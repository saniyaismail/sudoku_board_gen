"""
A helper module that can be used by all problems
"""
import numpy as np


"""
Generate random map based on the input Parameters

Parameters:
    random (numpy.random): random object to help generate the map
    width (int): the generated map width
    height (int): the generated map height
    prob (dict(int,float)): the probability distribution of each tile value

Returns:
    int[][]: the random generated map
"""
def gen_random_map(random, width, height, prob):
    map = random.choice(list(prob.keys()),size=(height,width),p=list(prob.values())).astype(np.uint8)
    return map

"""
A method to convert the map to use the tile names instead of tile numbers

Parameters:
    map (numpy.int[][]): a numpy 2D array of the current map
    tiles (string[]): a list of all the tiles in order

Returns:
    string[][]: a 2D map of tile strings instead of numbers
"""
def get_string_map(map, tiles):
    int_to_string = dict((i, s) for i, s in enumerate(tiles))
    result = []
    for y in range(map.shape[0]):
        result.append([])
        for x in range(map.shape[1]):
            result[y].append(int_to_string[int(map[y][x])])
    return result

"""
A method to convert the probability dictionary to use tile numbers instead of tile names

Parameters:
    prob (dict(string,float)): a dictionary of the probabilities for each tile name
    tiles (string[]): a list of all the tiles in order

Returns:
    Dict(int,float): a dictionary of tile numbers to probability values (sum to 1)
"""
def get_int_prob(prob, tiles):
    string_to_int = dict((s, i) for i, s in enumerate(tiles))
    result = {}
    total = 0.0
    for t in tiles:
        result[string_to_int[t]] = prob[t]
        total += prob[t]
    for i in result:
        result[i] /= total
    return result


def pretty_print_sudoku(board):
    if len(board) != 9 or any(len(row) != 9 for row in board):
        raise ValueError("Sudoku board must be a 9x9 list.")

    print("-" * 29)
    for i, row in enumerate(board):
        row_str = ""
        for j, val in enumerate(row):
            cell = val if val != 0 else "."
            row_str += f" {cell} "
            if (j + 1) % 3 == 0 and j < 8:
                row_str += "|"
        print(row_str)
        if (i + 1) % 3 == 0 and i < 8:
            print("-" * 29)
    print("-" * 29)


def pretty_print_validity_map(validity_map):
    if len(validity_map) != 9 or any(len(row) != 9 for row in validity_map):
        raise ValueError("Validity map must be a 9x9 list.")
    print("-" * 29)
    for i, row in enumerate(validity_map):
        row_str = ""
        for j, val in enumerate(row):
            cell = "✓" if val else "✗"
            row_str += f" {cell} "
            if (j + 1) % 3 == 0 and j < 8:
                row_str += "|"
        print(row_str)
        if (i + 1) % 3 == 0 and i < 8:
            print("-" * 29)
    print("-" * 29)

