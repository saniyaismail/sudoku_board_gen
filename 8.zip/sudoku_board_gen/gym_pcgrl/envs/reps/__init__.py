from gym_pcgrl.envs.reps.wide_rep import WideRepresentation

# all the representations should be defined here with its corresponding class
REPRESENTATIONS = {
    "wide": WideRepresentation
}
