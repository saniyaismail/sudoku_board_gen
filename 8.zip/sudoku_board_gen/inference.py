"""
Run a trained agent and get generated maps
"""
import model
from stable_baselines import PPO2
from norvig import solve, display
from gym_pcgrl.envs.helper import pretty_print_sudoku

import time
from utils import make_vec_envs

def infer(game, representation, model_path, **kwargs):
    """
     - max_trials: The number of trials per evaluation.
     - infer_kwargs: Args to pass to the environment.
    """
    env_name = '{}-{}-v0'.format(game, representation)
    # print(env_name)
    if game == "sudoku":
        model.FullyConvPolicy = model.FullyConvPolicySmallMap
        kwargs['cropped_size'] = 9

    kwargs['render'] = True

    agent = PPO2.load(model_path)
    env = make_vec_envs(env_name, representation, None, 1, **kwargs)
    obs = env.reset()
    images = []
    for i in range(kwargs.get('trials', 1)):
        obs = env.reset()
        dones = False
        while not dones:
            action, _ = agent.predict(obs)
            obs, _, dones, info = env.step(action)

            img = env.render(mode='rgb_array')
            images.append(img)  # PIL.Image

            if kwargs.get('verbose', False):
                # print(info[0])
                pass
            if dones:
                final_board = info[0].get('map')
                num_solutions = "Unique" if info[0].get('solutions') == 1  else "Multiple"
                print(f"({i}) Generated board:")
                pretty_print_sudoku(final_board)
                string_board = ''.join(str(cell) if cell != 0 else '.' for row in final_board for cell in row)
                print("")
                print("Passing the board to the solver...")
                print("")
                print("Solutions: ", num_solutions)
                print(f"({i}) Solved board:", i)
                display(solve(string_board))
                print("\n\n========================================================\n\n")
                break
        time.sleep(0.2)
    output_gif_path = f"board_generation.gif"
    images[0].save(
        output_gif_path,
        save_all=True,
        append_images=images[1:],
        duration=300,  # milliseconds per frame
        loop=0
    )
    # print(f"Saved GIF to {output_gif_path}")

################################## MAIN ########################################
game = 'sudoku'
representation = 'wide'
model_path = 'runs/sudoku_wide_4_log/best_model.pkl'
kwargs = {
    'change_percentage': 0.4,
    'trials': 1,
    'verbose': True
}

if __name__ == '__main__':
    infer(game, representation, model_path, **kwargs)
