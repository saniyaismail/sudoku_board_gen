Source for all puzzles in this directory:
http://www.norvig.com/sudoku.html