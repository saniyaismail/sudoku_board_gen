def count_solutions(file_path):
    unique_count = 0
    multiple_count = 0

    with open(file_path, 'r') as f:
        for line in f:
            if "Solutions:" in line:
                if "Unique" in line:
                    unique_count += 1
                elif "Multiple" in line:
                    multiple_count += 1

    print(f"Unique solution boards: {unique_count}")
    print(f"Multiple solution boards: {multiple_count}")

if __name__ == "__main__":
    count_solutions("eval.txt")
